package com.powernode.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.powernode.domain.Category;
import com.powernode.domain.Prod;

import java.util.List;

public interface SearchService {
    Page<Prod> queryWxProdPageByTagId(Long current, Long size, Long tagId);

    List<Prod> queryWxProdListByCategoryId(Long categoryId);
}
