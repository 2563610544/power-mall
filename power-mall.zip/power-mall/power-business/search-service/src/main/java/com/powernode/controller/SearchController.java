package com.powernode.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.powernode.domain.Category;
import com.powernode.domain.Prod;
import com.powernode.model.Result;
import com.powernode.service.SearchService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


/**
 * 搜索业务控制层
 */
@RestController
@Api(tags= "搜索业务控制层")
//@RequestMapping("")
public class SearchController {

    @Autowired
    private SearchService searchService;

    @ApiOperation("根据分组标签分页查询商品")
    @GetMapping("prod/prodListByTagId")
    public Result<Page<Prod>> loadWxProdPageByTagId(@RequestParam(defaultValue = "1") Long current,
                                                    @RequestParam Long size,
                                                    @RequestParam Long tagId){


        //根据分组标签分页查询商品
        Page<Prod> page=searchService.queryWxProdPageByTagId(current,size,tagId);
        return Result.success(page);
    }

    @ApiOperation("根据商品类目标识查询集合")
    @GetMapping("prod/category/prod/list")
    public Result<List<Prod>> loadWxProdListByCategoryId(@RequestParam Long categoryId){
        //根据商品类目标识查询商品集合
        List<Prod>  list=searchService.queryWxProdListByCategoryId(categoryId);
        return Result.success(list);
    }


}
