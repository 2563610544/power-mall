package com.powernode.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.powernode.domain.Order;
import com.baomidou.mybatisplus.extension.service.IService;
import com.powernode.vo.OrderStatusCount;

import java.util.Date;

public interface OrderService extends IService<Order>{


    Page<Order> queryOrderPage(Page<Order> page, String orderNumber, Integer status, Date startTime, Date endTime);


    Order queryOrderDetailByOrderNumber(Long orderNumber);

    OrderStatusCount queryMemberOrderStatusCount();

    Page<Order> queryMemberOrderPage(Long current,Long size, Long status);

    Order queryMemberOrderDetailByOrderNumber(String orderNumber);

    Boolean receiptMemberOrder(String orderNumber);

    Boolean removeMemberOrderByOrderNumber(String orderNumber);
}
