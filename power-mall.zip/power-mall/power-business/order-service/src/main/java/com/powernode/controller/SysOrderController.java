package com.powernode.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.powernode.domain.Notice;
import com.powernode.domain.Order;
import com.powernode.model.Result;
import com.powernode.service.OrderService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
//wxaf7ca17a202c3131
//60e303b24cf2bae5928d9471f8cee5a0
//60e303b24cf2bae5928d9471f8cee5a0
@Api(tags="订单业务接口管理")
@RequestMapping("order/order")
@RestController
public class SysOrderController {

    @Autowired
    private OrderService orderService;


    /**
     *
     * @param current
     * @param size
     * @param orderNumber
     * @param status
     * @param startTime
     * @param endTime
     * @return
     */
    @ApiOperation("多条件分页查询订单")
    @GetMapping("page")
    @PreAuthorize("hasAuthority('order:order:page')")
    public Result<Page<Order>> loadOrderPage(@RequestParam Long current,
                                             @RequestParam Long size,
                                             @RequestParam(required = false) String orderNumber,
                                             @RequestParam(required = false) Integer status,
                                             @RequestParam(required = false) Date startTime,
                                             @RequestParam(required = false) Date endTime){
        //创建订单分页对象
        Page<Order> page = new Page<>(current,size);
        //多条件分页查询订单
        page=orderService.queryOrderPage(page,orderNumber,status,startTime,endTime);
        return Result.success(page);




    }


    /**
     * 根据订单编号查询订单详情
     * @param orderNumber 订单编号
     * @return
     */
    @ApiOperation("根据订单编号查询订单详情")
    @GetMapping("orderInfo/{orderNumber}")
    @PreAuthorize("hasAuthority('order:order:info')")
    public Result<Order> loadOrderDetail(@PathVariable Long orderNumber){
       Order order=orderService.queryOrderDetailByOrderNumber(orderNumber);
        return Result.success(order);
    }

    @ApiOperation("导出销售记录")
    @GetMapping("soldExcel")
    @PreAuthorize("hasAuthority('order:order:soldExcel')")
    public Result<String> exportSoleOrderRecordExcel(){
        //查询所有销售记录
        List<Order> list = orderService.list(new LambdaQueryWrapper<Order>()
                .orderByDesc(Order::getCreateTime)
        );
        return null;

    }



}
