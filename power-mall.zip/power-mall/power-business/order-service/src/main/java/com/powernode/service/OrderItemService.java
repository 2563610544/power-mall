package com.powernode.service;

import com.powernode.domain.OrderItem;
import com.baomidou.mybatisplus.extension.service.IService;
public interface OrderItemService extends IService<OrderItem>{


}
