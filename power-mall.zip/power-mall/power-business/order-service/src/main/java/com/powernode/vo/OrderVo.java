package com.powernode.vo;

import com.powernode.model.ShopOrder;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 订单确认页面对象
 */

@ApiModel("订单确认页面对象")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OrderVo {
    @ApiModelProperty("订单店铺对象集合")
    private List<ShopOrder> shopOrderList;


}
