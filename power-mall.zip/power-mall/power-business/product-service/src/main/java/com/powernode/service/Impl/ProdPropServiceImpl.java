package com.powernode.service.Impl;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.plugins.pagination.PageDTO;
import com.powernode.constant.ProductConstants;
import com.powernode.domain.ProdPropValue;
import com.powernode.mapper.ProdPropValueMapper;
import com.powernode.service.ProdPropValueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.powernode.mapper.ProdPropMapper;
import com.powernode.domain.ProdProp;
import com.powernode.service.ProdPropService;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

@Service
@CacheConfig(cacheNames = "com.powernode.service.Impl.ProdPropServiceImpl")
public class ProdPropServiceImpl extends ServiceImpl<ProdPropMapper, ProdProp> implements ProdPropService{

    @Autowired
    private ProdPropMapper prodPropMapper;

    @Autowired
    private ProdPropValueMapper prodPropValueMapper;


    @Autowired
    private ProdPropValueService prodPropValuesService;

    @Override
    public Page<ProdProp> queryProdSpecPage(Long current, Long size, String propName) {
        //创建分页对象
        Page<ProdProp> page = new Page<>(current,size);
        //多条件分页查询商品属性
        page = prodPropMapper.selectPage(page, new LambdaQueryWrapper<ProdProp>()
                .like(StringUtils.hasText(propName), ProdProp::getPropName, propName)

        );

        //从分页对象中获取属性记录
        List<ProdProp> prodPropList = page.getRecords();
        //判断是否有值
        if(CollectionUtil.isEmpty(prodPropList)|| prodPropList.size()==0){
            //如果属性对象集合没有值，说明属性值为空
            return  page;
        }
        //从属性对象集合中获取属性id集合
        List<Long> propIdList = prodPropList.stream().map(ProdProp::getPropId).collect(Collectors.toList());

        //属性id集合查询属性值对象集合
        List<ProdPropValue> prodPropValueList = prodPropValueMapper.selectList(new LambdaQueryWrapper<ProdPropValue>()
                .in(ProdPropValue::getPropId, propIdList)

        );
        //循环遍历属性对象集合
        prodPropList.forEach(prodProp -> {
            //从属性值对象集合中过滤出与当前属性对象的属性id一致的属性对象集合
            List<ProdPropValue> propValues = prodPropValueList.stream().filter(prodPropValue -> prodPropValue.getPropId()
                    .equals(prodProp.getPropId()))
                    .collect(Collectors.toList());
            prodProp.setProdPropValues(propValues);

        });
        return page;
    }

    /**
     * 新增商品属性对象
     * 1.新增商品属性对象->属性id
     * 2.批量添加商品属性值对象
     * @param prodProp
     * @return
     */
    @Override
    @CacheEvict(key =ProductConstants.PROD_PROP_KEY )
    @Transactional(rollbackFor = Exception.class)
    public Boolean saveProdSpec(ProdProp prodProp) {
        //新增商品属性对象
        prodProp.setShopId(1L);
        prodProp.setRule((byte) 2);
        int i=prodPropMapper.insert(prodProp);
        if(i>0){
            //获取属性id
            List<ProdProp> prodProps = prodPropMapper.selectList(new LambdaQueryWrapper<ProdProp>()
                    .eq(ProdProp::getPropName, prodProp.getPropName())
            );
            List<ProdPropValue> prodPropValues = prodProp.getProdPropValues();
            prodProp=prodProps.get(0);
            Long propId = prodProp.getPropId();
            //添加属性对象与属性值的对象
            //获取商品属性值集合

            //判断是否有值
            if(CollectionUtil.isNotEmpty(prodPropValues)&&prodPropValues.size()!=0){
                //循环遍历属性值对象集合
                prodPropValues.forEach(prodPropValue -> prodPropValue.setPropId(propId));
                //批量添加属性值对象集合
                prodPropValuesService.saveBatch(prodPropValues);
            }


        }

        return i>0;
    }

    @Override
    @CacheEvict(key =ProductConstants.PROD_PROP_KEY )
    @Transactional(rollbackFor = Exception.class)
    public Boolean modifyProdSpec(ProdProp prodProp) {
        //Long propId = prodProp.getPropId();
        //添加属性对象与属性值的对象
        //获取商品属性值集合
        List<ProdPropValue> prodPropValues = prodProp.getProdPropValues();
        prodPropValuesService.updateBatchById(prodPropValues);
        return prodPropMapper.updateById(prodProp)>0;
    }

    @Override
    @CacheEvict(key =ProductConstants.PROD_PROP_KEY )
    @Transactional(rollbackFor = Exception.class)
    public Boolean removeProdPropById(Long propId) {
        prodPropValueMapper.delete(new LambdaQueryWrapper<ProdPropValue>()
              .eq(ProdPropValue::getPropId,propId)

        );
        return prodPropMapper.deleteById(propId)>0;
    }

    /**
     * 查询系统商品属性集合
     * @return
     */
    @Override
    @Cacheable(key =ProductConstants.PROD_PROP_KEY )
    public List<ProdProp> queryProdPropList() {
        return prodPropMapper.selectList(null);

    }
}
