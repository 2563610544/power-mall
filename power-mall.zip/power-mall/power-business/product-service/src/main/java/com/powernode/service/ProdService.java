package com.powernode.service;

import com.powernode.domain.Prod;
import com.baomidou.mybatisplus.extension.service.IService;
public interface ProdService extends IService<Prod>{


    Boolean saveProd(Prod prod);

    Prod queryProdInfoById(Long prodId);

    Boolean modifyProdById(Prod prod);

    Boolean removeProdById(Long prodId);

    Prod queryWxProdInfoByProdId(Long prodId);
}
