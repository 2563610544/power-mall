package com.powernode.service;

import com.powernode.domain.Category;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

public interface
CategoryService extends IService<Category>{


    List<Category> queryAllCategoryList();

    /**
     * 查询系统商品一级类目
     *
     */
    List<Category> queryFirstCategoryList();

    /**
     * 新增商品目录
     * @param category
     * @return
     */
    Boolean saveCategory(Category category);

    /**
     * 修改商品类目信息
     * @param category
     * @return
     */
    Boolean modifyCategory(Category category);



    /**
     * 删除商品类目
     * @param categoryId 商品类目标识
     */
    Boolean removeCategoryById(Long categoryId);

    List<Category> queryWxCategoryListByPid(Long pid);
}
