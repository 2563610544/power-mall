package com.powernode.service;

import com.powernode.domain.ProdTagReference;
import com.baomidou.mybatisplus.extension.service.IService;
public interface ProdTagReferenceService extends IService<ProdTagReference>{


}
