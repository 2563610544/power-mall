package com.powernode.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.powernode.domain.ProdComm;
import com.baomidou.mybatisplus.extension.service.IService;
import com.powernode.vo.ProdCommData;

public interface ProdCommService extends IService<ProdComm>{


    Boolean replyAndExamineProdComm(ProdComm prodComm);

    ProdCommData queryWxProdCommDataByProdId(Long prodId);

    Page<ProdComm> queryWxProdCommPageByProd(Long current, Long size, Long prodId, Long evaluate);
}
