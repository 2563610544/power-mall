package com.powernode.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.powernode.domain.Category;
import com.powernode.domain.ProdProp;
import com.powernode.domain.ProdPropValue;
import com.powernode.domain.ProdTag;
import com.powernode.model.Result;
import com.powernode.service.ProdPropService;
import com.powernode.service.ProdPropValueService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 商品规格管理控制层
 */
@Api(tags="商品规格接口管理")
@RequestMapping("prod/spec")
@RestController
public class ProdSpecController {
    @Autowired
    private ProdPropService prodPropService;

    @Autowired
    private ProdPropValueService prodPropValueService;

    /**
     *多条件分页查询商品规格
     */
    @ApiOperation("多条件分页查询商品规格")
    @GetMapping("page")
    @PreAuthorize("hasAuthority('prod:spec:page')")
    public Result<Page<ProdProp>> loadProdSpecPage(@RequestParam Long current,
                                                   @RequestParam Long size,
                                                   @RequestParam(required = false) String propName){

        //多条件分页查询商品规格
        Page<ProdProp>   page=prodPropService.queryProdSpecPage(current,size,propName);
        return Result.success(page);

    }

    /**
     * 新增商品规格
     */
    @ApiOperation("新增商品规格")
    @PostMapping
    @PreAuthorize("hasAuthority('prod:spec:save')")
    public Result<String> saveProdSpec(@RequestBody ProdProp prodProp){
        Boolean saved=prodPropService.saveProdSpec(prodProp);
        return Result.handle(saved);
    }


    /**
     * 修改商品规格信息
     */
    @ApiOperation("修改商品规格信息")
    @PutMapping
    @PreAuthorize("hasAuthority('prod:spec:update')")
    public Result<String> modifyCategory(@RequestBody ProdProp prodProp){
        Boolean modified=prodPropService.modifyProdSpec(prodProp);
        return Result.handle(modified);
    }

    /**
     * 删除商品规格信息
     */
    @ApiOperation("删除商品规格信息")
    @DeleteMapping("{propId}")
    @PreAuthorize("hasAuthority('prod:spec:delete')")
    public Result<String> removeCategory(@PathVariable Long propId){
        Boolean removed=prodPropService.removeProdPropById(propId);
        return Result.handle(removed);
    }


    /**
     *查询系统商品属性集合
     *
     */
    @ApiOperation("查询系统商品属性集合")
    @GetMapping("list")
    @PreAuthorize("hasAuthority('prod:spec:page')")
    public Result<List<ProdProp>> laodProdPropList(){
        List<ProdProp> prodProps=prodPropService.queryProdPropList();
        return Result.success(prodProps);
    }

    /**
     *根据商品属性id查询属性值集合
     *
     */
    @ApiOperation("根据商品属性id查询属性值集合")
    @GetMapping("listSpecValue/{propId}")
    @PreAuthorize("hasAuthority('prod:spec:page')")
    public Result<List<ProdPropValue>> laodProdPropValues(@PathVariable Long propId){
        List<ProdPropValue> prodPropsValues=prodPropValueService.list(new LambdaQueryWrapper<ProdPropValue>()
                         .eq(ProdPropValue::getPropId,propId)

        );
        return Result.success(prodPropsValues);
    }




}
