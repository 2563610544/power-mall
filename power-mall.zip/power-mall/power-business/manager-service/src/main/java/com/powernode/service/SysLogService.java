package com.powernode.service;

import com.powernode.domain.SysLog;
import com.baomidou.mybatisplus.extension.service.IService;
public interface SysLogService extends IService<SysLog>{


}
