package com.powernode.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.powernode.domain.SysUser;

public interface SysUserMapper extends BaseMapper<SysUser> {
}