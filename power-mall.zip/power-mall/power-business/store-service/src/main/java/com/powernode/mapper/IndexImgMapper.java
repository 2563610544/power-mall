package com.powernode.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.powernode.domain.IndexImg;

public interface IndexImgMapper extends BaseMapper<IndexImg> {
}