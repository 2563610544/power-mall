package com.powernode.service;

import com.powernode.domain.IndexImg;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

public interface IndexImgService extends IService<IndexImg>{


    Boolean saveIndexImg(IndexImg indexImg);

    Boolean modifyIndexImg(IndexImg indexImg);

    IndexImg queryIndexImgInfoById(Long imgId);

    Boolean removeIndexImgByIds(List<Long> imgIds);

    List<IndexImg> queryWxIndexImgList();
}
