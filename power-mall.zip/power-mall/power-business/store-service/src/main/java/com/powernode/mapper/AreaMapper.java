package com.powernode.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.powernode.domain.Area;

public interface AreaMapper extends BaseMapper<Area> {
}