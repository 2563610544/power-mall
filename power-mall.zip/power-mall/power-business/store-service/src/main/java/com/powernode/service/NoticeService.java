package com.powernode.service;

import com.powernode.domain.Notice;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

public interface NoticeService extends IService<Notice>{


    Boolean saveNotice(Notice notice);

    Boolean modifyNotice(Notice notice);

    List<Notice> queryWxTopNoticeList();

    List<Notice> queryWxAllNoticeList();
}
