package com.powernode.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.powernode.domain.MemberAddr;
import com.powernode.model.Result;
import com.powernode.service.MemberAddrService;
import com.powernode.util.AuthUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

/**
 * 会员收货地址管理控制层
 */
@Api(tags = "会员收货地址管理控制层")
@RestController
@RequestMapping("p/address")
public class MemberAddrController {

    @Autowired
    private MemberAddrService memberAddrService;



    @ApiOperation("查询会员所有收货地址")
    @GetMapping("list")
    public Result<List<MemberAddr>> loadMemberAddrList(){
        String openId = AuthUtils.getMemberOpenId();
        List<MemberAddr> memberAddrs= memberAddrService.queryMemberAddrListByOpenId(openId);
       return Result.success(memberAddrs);
    }

    @ApiOperation("查询会员收货地址详情")
    @GetMapping("addrInfo/{addrId}")
    public Result<MemberAddr> loadMemberAddrInfo(@PathVariable Long addrId){
        MemberAddr memberAddr= memberAddrService.getById(addrId);
        return Result.success(memberAddr);
    }



    @ApiOperation("新增会员收货地址")
    @PostMapping
    public Result<String> saveMemberAddr(@RequestBody MemberAddr memberAddr){
        String openId = AuthUtils.getMemberOpenId();


        Boolean saved= memberAddrService.saveMemberAddr(memberAddr,openId);

        return Result.handle(saved);
    }


    @ApiOperation("修改会员收货地址")
    @PutMapping
    public Result<String> modifyMemberAddr(@RequestBody MemberAddr memberAddr){
        String openId = AuthUtils.getMemberOpenId();
        Boolean modied= memberAddrService.modifyAddrInfo(memberAddr,openId);
        return Result.handle(modied);
    }

    @ApiOperation("删除会员收货地址")
    @DeleteMapping("deleteAddr/{addrId}")
    public Result<String> removeMemberAddr(@PathVariable Long addrId){
        String openId = AuthUtils.getMemberOpenId();
        Boolean removed= memberAddrService.removeMemberAddrById(addrId,openId);
        return Result.handle(removed);
    }


    @ApiOperation("会员设置默认收货地址")
    @PutMapping("defaultAddr/{newAddrId}")
    public Result<String> modifyMemberDefaultAddr(@PathVariable Long newAddrId){
        String openId = AuthUtils.getMemberOpenId();
        Boolean modified= memberAddrService.modifyMemberDefaultAddr(openId,newAddrId);
        return Result.handle(modified);
    }








    /////////////////feign接口/////////////////////////
    @GetMapping("getMemberAddrById")
    public Result<MemberAddr> getMemberAddrById(@RequestParam Long addrId){
        MemberAddr memberAddr = memberAddrService.getById(addrId);
        return Result.success(memberAddr);
    }





}
