package com.powernode.service;

import com.powernode.domain.Member;
import com.baomidou.mybatisplus.extension.service.IService;
public interface MemberService extends IService<Member>{


    Boolean modifyMemberInfoByOpenId(Member member);
}
