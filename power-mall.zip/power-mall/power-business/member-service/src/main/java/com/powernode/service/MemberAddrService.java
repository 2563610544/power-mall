package com.powernode.service;

import com.powernode.domain.MemberAddr;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

public interface MemberAddrService extends IService<MemberAddr>{

    /**
     * 查询会员所有收货地址
     * @param openId
     * @return
     */

    List<MemberAddr> queryMemberAddrListByOpenId(String openId);

    Boolean saveMemberAddr(MemberAddr memberAddr,String openId);

    Boolean modifyAddrInfo(MemberAddr memberAddr, String openId);

    Boolean removeMemberAddrById(Long addrId, String openId);

    Boolean modifyMemberDefaultAddr(String openId, Long newAddrId);
}
