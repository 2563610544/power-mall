package com.powernode.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.powernode.domain.MemberCollection;
import com.baomidou.mybatisplus.extension.service.IService;
import com.powernode.domain.Prod;

public interface MemberCollectionService extends IService<MemberCollection>{


    Long queryMemberCollectionProdCount();

    Page<Prod> queryMemberCollectionProdPageByOpenId(String memberOpenId, Long current, Long size);

    Boolean addOrCancelMemberCollection(String openId, Long prodId);
}
