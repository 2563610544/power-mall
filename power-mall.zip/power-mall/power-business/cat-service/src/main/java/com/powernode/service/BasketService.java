package com.powernode.service;

import com.powernode.domain.Basket;
import com.baomidou.mybatisplus.extension.service.IService;
import com.powernode.vo.CartTotalAmount;
import com.powernode.vo.CartVo;

import java.util.List;

public interface BasketService extends IService<Basket>{


    Integer queryMemberBasketProdCount(String openId);

    CartVo queryMemberCartVo();

    CartTotalAmount caluculateMemberCheckedBasketTotalAmount(List<Long> basketIds);


    /**
     * 添加商品到购物车或修改商品在购物车中的数量
     * @param basket
     * @return
     */
    Boolean changeCartItem(Basket basket);
}
