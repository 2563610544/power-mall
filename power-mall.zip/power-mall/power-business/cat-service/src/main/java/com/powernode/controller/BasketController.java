package com.powernode.controller;



import com.powernode.domain.Basket;
import com.powernode.model.Result;
import com.powernode.service.BasketService;
import com.powernode.util.AuthUtils;
import com.powernode.vo.CartTotalAmount;
import com.powernode.vo.CartVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.ehcache.xml.model.CacheTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 购物车业务控制层
 */
@Api(tags="购物车业务接口管理")
@RestController
@RequestMapping("p/shopCart")
public class BasketController {

    @Autowired
    private BasketService basketService;

    @ApiOperation("查询会员购物车商品数量")
    @GetMapping("prodCount")
    public Result<Integer> loadMemberBasketProdCount(){
        String openId = AuthUtils.getMemberOpenId();
        Integer  count=basketService.queryMemberBasketProdCount(openId);
        return Result.success(count);

    }

    @ApiOperation("查询会员购物车页面数据")
    @GetMapping("info")
    public Result<CartVo> loadMemberCartVo(){
        CartVo cartVo=basketService.queryMemberCartVo();
       return Result.success(cartVo);


    }


    @ApiOperation("计算会员选中购物车中商品的金额")
    @PostMapping("totalPay")
    public Result<CartTotalAmount> calculateMemberCheckedBasketTotalAmount(@RequestBody List<Long> basketIds){
        CartTotalAmount cartTotalAmount=basketService.caluculateMemberCheckedBasketTotalAmount(basketIds);
        return Result.success(cartTotalAmount);


    }

    /**
     *添加商品到购物车后者修改商品在购物车中的数量
     * @param basket
     * @return
     */
    @ApiOperation("添加商品到购物车或修改商品在购物车中的数量")
    @PostMapping("changeItem")
    public Result<String> changeCartItem(@RequestBody Basket basket){
       Boolean changed=basketService.changeCartItem(basket);
        return Result.handle(changed);


    }



    @ApiOperation("删除会员选中的购物车记录")
    @DeleteMapping("deleteItem")
    public Result<String> removeMemberCheckedBasket(@RequestBody List<Long> basketIds){
        boolean removed = basketService.removeBatchByIds(basketIds);
        return Result.handle(removed);


    }





}
