package com.powernode.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.powernode.domain.ProdProp;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProdPropMapper extends BaseMapper<ProdProp> {
}